package com.igorcordeiroszeremeta.coronavirusapp6;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button botaoInicial1;
    private Button botaoInicial2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botaoInicial1 = findViewById(R.id.botaoInicial1);
        botaoInicial1.setOnClickListener(new View.OnClickListener(){
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(getApplication(), MainActivity1.class);
               startActivity(intent);
           }
        });

        botaoInicial2 = findViewById(R.id.botaoInicial2);
        botaoInicial2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent intent = new Intent(getApplication(), Teste1.class);
            startActivity(intent);
            }
        });
    }
}