package com.igorcordeiroszeremeta.coronavirusapp6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Teste1 extends AppCompatActivity {

    CheckBox febre;
    CheckBox tosseSeca;
    CheckBox cansaco;
    Button botaoPaginaAnterior1;
    Button botaoProximo1;
    TextView textoDoResultado1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.teste);

        botaoProximo1 = findViewById(R.id.botaoProximo4);
        febre = findViewById(R.id.febre);
        tosseSeca = findViewById(R.id.tosseSeca);
        cansaco = findViewById(R.id.cansaco);
        botaoPaginaAnterior1 = findViewById(R.id.botaoPaginaAnterior4);
        textoDoResultado1 = findViewById(R.id.textoDoResultado4);

        botaoProximo1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                int resultadoDaPrimeiraPagina = 0;

                if (febre.isChecked()) {
                    resultadoDaPrimeiraPagina += 1;
                }

                if (tosseSeca.isChecked()) {
                    resultadoDaPrimeiraPagina += 3;
                }

                if (cansaco.isChecked()) {
                    resultadoDaPrimeiraPagina += 3;
                }
                textoDoResultado1.setText(String.valueOf(resultadoDaPrimeiraPagina));
                Intent intentEnviadora = new Intent(getApplicationContext(), Teste2.class);
                Bundle parametro = new Bundle();

                parametro.putInt("resultado1", resultadoDaPrimeiraPagina);
                intentEnviadora.putExtras(parametro);
                startActivity(intentEnviadora);

                //   Intent intent = new Intent(getApplicationContext(), Teste1.class);
            }
        });

        botaoPaginaAnterior1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity4.class);
                startActivity(intent);
            }
        });
    }
}